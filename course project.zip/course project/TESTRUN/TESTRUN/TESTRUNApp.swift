//
//  TESTRUNApp.swift
//  TESTRUN
//
//  Created by june taylr on 4/5/26.
//

import SwiftUI

@main
struct TESTRUNApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
